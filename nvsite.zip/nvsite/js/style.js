var element = document.getElementById('myAlert')
myAlert.addEventListener('closed.bs.alert',function()  {
    if(login_usu != login_save )
})