fetch("https://tccfast-production.up.railway.app/usuarios").then((res) =>
  console.log(res)
);

fetch("https://windy-energy-396600.rj.r.appspot.com/produtos").then((res) =>
  console.log(res)
);