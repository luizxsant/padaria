document
  .getElementById("contact-form")
  .addEventListener("submit", function (e) {
    e.preventDefault(); 

    
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const message = document.getElementById("message").value;


    const formUrl = "https://formspree.io/YOUR_FORMSPREE_ENDPOINT";

    
    const requestOptions = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ name, email, message }),
    };

    // Envia a requisição
    fetch(formUrl, requestOptions)
      .then((response) => {
        if (response.ok) {
          alert("Mensagem enviada com sucesso!");
          document.getElementById("contact-form").reset();
        } else {
          alert(
            "Ocorreu um erro ao enviar a mensagem. Por favor, tente novamente mais tarde."
          );
        }
      })
      .catch((error) => {
        console.error("Erro:", error);
        alert(
          "Ocorreu um erro ao enviar a mensagem. Por favor, tente novamente mais tarde."
        );
      });
  });
